# Código do Projeto

Mantenha neste diretório todo o código fonte do projeto. 

Se necessário, descreva neste arquivo aspectos relevantes da estrutura de diretórios criada para organização do código.

# Domínio

https://assinu.tk/

## Acesso ao Domínio

Nome de usuário do FTP: assinu@assinu.tk

Servidor FTP: ftp.grupofidelizar.com

FTP & porta FTPS explícita:  21

Senha: x!qO4J&_Ak!e

